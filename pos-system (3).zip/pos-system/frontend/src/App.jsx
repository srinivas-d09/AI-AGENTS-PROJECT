import { useState } from "react";
import { CartProvider } from "./context/CartContext";
import Catalog from "./pages/Catalog";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import ResponseScreen from "./pages/ResponseScreen";
import "./App.css";

const SCREENS = {
  CATALOG:  "catalog",
  CART:     "cart",
  CHECKOUT: "checkout",
  RESPONSE: "response",
};

export default function App() {
  const [screen, setScreen]           = useState(SCREENS.CATALOG);
  const [n8nResponse, setN8nResponse] = useState(null);
  const [orderPayload, setOrderPayload] = useState(null);

  const handleSuccess = (response, payload) => {
    setN8nResponse(response);
    setOrderPayload(payload);
    setScreen(SCREENS.RESPONSE);
  };

  const handleNewOrder = () => {
    setN8nResponse(null);
    setOrderPayload(null);
    setScreen(SCREENS.CATALOG);
  };

  return (
    <CartProvider>
      <div className="app">
        {/* Step indicator */}
        {screen !== SCREENS.RESPONSE && (
          <div className="step-indicator">
            {[
              { id: SCREENS.CATALOG,  label: "Products", num: 1 },
              { id: SCREENS.CART,     label: "Cart",     num: 2 },
              { id: SCREENS.CHECKOUT, label: "Checkout", num: 3 },
            ].map(step => (
              <div
                key={step.id}
                className={`step ${screen === step.id ? "active" : ""} ${
                  [SCREENS.CART, SCREENS.CHECKOUT].includes(screen) && step.id === SCREENS.CATALOG ? "done" : ""
                } ${screen === SCREENS.CHECKOUT && step.id === SCREENS.CART ? "done" : ""}`}
              >
                <span className="step-num">{step.num}</span>
                <span className="step-label">{step.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Screens */}
        {screen === SCREENS.CATALOG && (
          <Catalog onViewCart={() => setScreen(SCREENS.CART)} />
        )}
        {screen === SCREENS.CART && (
          <Cart
            onBack={() => setScreen(SCREENS.CATALOG)}
            onCheckout={() => setScreen(SCREENS.CHECKOUT)}
          />
        )}
        {screen === SCREENS.CHECKOUT && (
          <Checkout
            onBack={() => setScreen(SCREENS.CART)}
            onSuccess={handleSuccess}
          />
        )}
        {screen === SCREENS.RESPONSE && (
          <ResponseScreen
            response={n8nResponse}
            orderPayload={orderPayload}
            onNewOrder={handleNewOrder}
          />
        )}
      </div>
    </CartProvider>
  );
}
