import { useState } from "react";
import { useCart } from "../context/CartContext";
import { formatINR, getActiveHeaderDiscount } from "../data/products";

const PAYMENT_METHODS = [
  { id: "razorpay", label: "Razorpay",          icon: "💳", desc: "UPI, Net Banking, Cards via Razorpay" },
  { id: "stripe",   label: "Stripe",             icon: "🌐", desc: "International cards via Stripe" },
  { id: "cod",      label: "Cash on Delivery",   icon: "💵", desc: "Pay with cash at counter" },
];

const INDIA_STATES = [
  "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat",
  "Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh",
  "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab",
  "Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh",
  "Uttarakhand","West Bengal","Delhi","Jammu & Kashmir","Ladakh","Puducherry",
];

// ── Payment detail sub-components ────────────────────────────

function RazorpayDetails({ value, onChange, error }) {
  return (
    <div className="payment-details-box razorpay">
      <div className="pd-header">
        <span className="pd-dot razorpay" />
        Enter Razorpay Transaction Details
      </div>
      <div className="field" style={{ marginTop: "12px" }}>
        <label>Payment ID / Transaction Reference *</label>
        <input
          value={value.paymentId}
          onChange={e => onChange({ ...value, paymentId: e.target.value })}
          placeholder="pay_XXXXXXXXXXXXXXXXXX"
        />
        {error?.paymentId && <span className="field-error">{error.paymentId}</span>}
      </div>
      <div className="field" style={{ marginTop: "12px" }}>
        <label>Payment Mode</label>
        <select
          value={value.mode}
          onChange={e => onChange({ ...value, mode: e.target.value })}
        >
          <option value="upi">UPI</option>
          <option value="netbanking">Net Banking</option>
          <option value="card">Card</option>
          <option value="wallet">Wallet</option>
        </select>
      </div>
      <p className="pd-note">
        💡 Enter the Razorpay payment ID after the customer completes payment on their device.
      </p>
    </div>
  );
}

function StripeDetails({ value, onChange, error }) {
  const formatCard = (val) => {
    return val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  };
  const formatExpiry = (val) => {
    const digits = val.replace(/\D/g, "").slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + "/" + digits.slice(2);
    return digits;
  };

  return (
    <div className="payment-details-box stripe">
      <div className="pd-header">
        <span className="pd-dot stripe" />
        Enter Card Details
      </div>
      <div className="field" style={{ marginTop: "12px" }}>
        <label>Card Number *</label>
        <input
          value={value.cardNumber}
          onChange={e => onChange({ ...value, cardNumber: formatCard(e.target.value) })}
          placeholder="1234 5678 9012 3456"
          maxLength={19}
        />
        {error?.cardNumber && <span className="field-error">{error.cardNumber}</span>}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginTop: "12px" }}>
        <div className="field">
          <label>Expiry (MM/YY) *</label>
          <input
            value={value.expiry}
            onChange={e => onChange({ ...value, expiry: formatExpiry(e.target.value) })}
            placeholder="08/28"
            maxLength={5}
          />
          {error?.expiry && <span className="field-error">{error.expiry}</span>}
        </div>
        <div className="field">
          <label>CVV *</label>
          <input
            type="password"
            value={value.cvv}
            onChange={e => onChange({ ...value, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })}
            placeholder="•••"
            maxLength={4}
          />
          {error?.cvv && <span className="field-error">{error.cvv}</span>}
        </div>
      </div>
      <div className="field" style={{ marginTop: "12px" }}>
        <label>Name on Card *</label>
        <input
          value={value.nameOnCard}
          onChange={e => onChange({ ...value, nameOnCard: e.target.value })}
          placeholder="ARJUN SHARMA"
        />
        {error?.nameOnCard && <span className="field-error">{error.nameOnCard}</span>}
      </div>
      <p className="pd-note">
        🔒 Card details are processed securely via Stripe and never stored.
      </p>
    </div>
  );
}

function CODDetails({ grandTotal, value, onChange }) {
  const tendered = parseFloat(value.tendered) || 0;
  const change   = tendered - grandTotal;

  const QUICK_AMOUNTS = [
    Math.ceil(grandTotal / 100) * 100,
    Math.ceil(grandTotal / 500) * 500,
    Math.ceil(grandTotal / 1000) * 1000,
  ].filter((v, i, a) => a.indexOf(v) === i && v >= grandTotal).slice(0, 3);

  return (
    <div className="payment-details-box cod">
      <div className="pd-header">
        <span className="pd-dot cod" />
        Cash Payment
      </div>

      <div className="cod-total-due">
        <span className="cod-label">Amount Due</span>
        <span className="cod-amount">{formatINR(grandTotal)}</span>
      </div>

      <div className="field" style={{ marginTop: "12px" }}>
        <label>Amount Tendered by Customer (₹)</label>
        <input
          type="number"
          value={value.tendered}
          onChange={e => onChange({ ...value, tendered: e.target.value })}
          placeholder={grandTotal.toString()}
          min={0}
        />
      </div>

      {QUICK_AMOUNTS.length > 0 && (
        <div className="cod-quick-amounts">
          <span className="cod-quick-label">Quick:</span>
          {QUICK_AMOUNTS.map(amt => (
            <button
              key={amt}
              className="cod-quick-btn"
              onClick={() => onChange({ ...value, tendered: amt.toString() })}
            >
              ₹{amt.toLocaleString("en-IN")}
            </button>
          ))}
        </div>
      )}

      {tendered > 0 && (
        <div className={"cod-change-row " + (change >= 0 ? "positive" : "negative")}>
          <span>{change >= 0 ? "💰 Change to Return" : "⚠️ Short by"}</span>
          <span className="cod-change-amount">
            {formatINR(Math.abs(change))}
          </span>
        </div>
      )}

      <p className="pd-note" style={{ marginTop: "12px" }}>
        💡 Collect cash before confirming the order.
      </p>
    </div>
  );
}

// ── Main Checkout Component ───────────────────────────────────

export default function Checkout({ onBack, onSuccess }) {
  const { items, computeTotals, clearCart } = useCart();
  const headerDiscount = getActiveHeaderDiscount();
  const totals = computeTotals(headerDiscount);

  const [form, setForm] = useState({
    name: "", email: "", phone: "",
    line1: "", city: "", state: "Karnataka", pincode: "",
  });
  const [paymentMethod, setPaymentMethod] = useState("razorpay");
  const [notes, setNotes]   = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors]   = useState({});

  // Payment-specific details
  const [razorpayDetails, setRazorpayDetails] = useState({ paymentId: "", mode: "upi" });
  const [stripeDetails,   setStripeDetails]   = useState({ cardNumber: "", expiry: "", cvv: "", nameOnCard: "" });
  const [codDetails,      setCodDetails]      = useState({ tendered: "" });

  const set = (field) => (e) => {
    setForm(prev => ({ ...prev, [field]: e.target.value }));
    setErrors(prev => ({ ...prev, [field]: "" }));
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim())    e.name    = "Name is required";
    if (!form.email.trim())   e.email   = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Invalid email";
    if (!form.phone.trim())   e.phone   = "Phone is required";
    if (!form.line1.trim())   e.line1   = "Address line is required";
    if (!form.city.trim())    e.city    = "City is required";
    if (!form.pincode.trim()) e.pincode = "Pincode is required";
    else if (!/^\d{6}$/.test(form.pincode)) e.pincode = "Must be 6 digits";

    // Payment-specific validation
    if (paymentMethod === "razorpay") {
      if (!razorpayDetails.paymentId.trim()) e.paymentId = "Payment ID is required";
    }
    if (paymentMethod === "stripe") {
      if (!stripeDetails.cardNumber.replace(/\s/g, "") || stripeDetails.cardNumber.replace(/\s/g, "").length < 16)
        e.cardNumber = "Valid card number required";
      if (!stripeDetails.expiry || stripeDetails.expiry.length < 5)
        e.expiry = "Valid expiry required";
      if (!stripeDetails.cvv || stripeDetails.cvv.length < 3)
        e.cvv = "Valid CVV required";
      if (!stripeDetails.nameOnCard.trim())
        e.nameOnCard = "Name on card is required";
    }
    return e;
  };

  const handleSubmit = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }

    setLoading(true);

    // Build payment_details for payload
    let payment_details = {};
    if (paymentMethod === "razorpay") {
      payment_details = { payment_id: razorpayDetails.paymentId, mode: razorpayDetails.mode };
    } else if (paymentMethod === "stripe") {
      payment_details = {
        last4:        stripeDetails.cardNumber.replace(/\s/g, "").slice(-4),
        name_on_card: stripeDetails.nameOnCard,
        // NOTE: never send raw card details to backend in production
      };
    } else if (paymentMethod === "cod") {
      payment_details = {
        tendered: parseFloat(codDetails.tendered) || totals.grandTotal,
        change:   Math.max(0, (parseFloat(codDetails.tendered) || 0) - totals.grandTotal),
      };
    }

    const payload = {
      customer: {
        name:    form.name.trim(),
        email:   form.email.trim(),
        phone:   form.phone.trim(),
        address: {
          line1:   form.line1.trim(),
          city:    form.city.trim(),
          state:   form.state,
          pincode: form.pincode.trim(),
        },
      },
      items: items.map(({ product, quantity }) => ({ sku: product.sku, quantity })),
      payment_method:  paymentMethod,
      payment_details,
      notes: notes.trim() || undefined,
      order_summary: {
        line_items:             totals.lineItems,
        total_product_discount: totals.totalProductDiscount,
        total_tax:              totals.totalTax,
        header_discount_name:   headerDiscount?.name || null,
        header_discount_pct:    headerDiscount?.value || 0,
        header_discount_amount: totals.headerDiscountAmount,
        grand_total:            totals.grandTotal,
      },
    };

    try {
      const res  = await fetch("http://localhost:8000/order", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(payload),
      });
      const data = await res.json();
      clearCart();
      onSuccess(data, payload);
    } catch (err) {
      onSuccess({ error: true, message: err.message }, payload);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page checkout-page">
      <header className="page-header">
        <button className="back-btn" onClick={onBack}>← Cart</button>
        <h2 className="page-title">Checkout</h2>
        <span className="total-chip">{formatINR(totals.grandTotal)}</span>
      </header>

      <div className="checkout-layout">
        {/* Left — Form */}
        <div className="checkout-form">

          {/* Customer Info */}
          <section className="form-section">
            <h3 className="section-title">👤 Customer Information</h3>
            <div className="form-grid">
              <div className={"field " + (errors.name ? "error" : "")}>
                <label>Full Name *</label>
                <input value={form.name} onChange={set("name")} placeholder="Arjun Sharma" />
                {errors.name && <span className="field-error">{errors.name}</span>}
              </div>
              <div className={"field " + (errors.email ? "error" : "")}>
                <label>Email *</label>
                <input type="email" value={form.email} onChange={set("email")} placeholder="arjun@example.com" />
                {errors.email && <span className="field-error">{errors.email}</span>}
              </div>
              <div className={"field " + (errors.phone ? "error" : "")}>
                <label>Phone *</label>
                <input value={form.phone} onChange={set("phone")} placeholder="+91 98765 43210" />
                {errors.phone && <span className="field-error">{errors.phone}</span>}
              </div>
            </div>
          </section>

          {/* Address */}
          <section className="form-section">
            <h3 className="section-title">📍 Delivery Address</h3>
            <div className="form-grid">
              <div className={"field full " + (errors.line1 ? "error" : "")}>
                <label>Address Line *</label>
                <input value={form.line1} onChange={set("line1")} placeholder="42 Brigade Road" />
                {errors.line1 && <span className="field-error">{errors.line1}</span>}
              </div>
              <div className={"field " + (errors.city ? "error" : "")}>
                <label>City *</label>
                <input value={form.city} onChange={set("city")} placeholder="Bengaluru" />
                {errors.city && <span className="field-error">{errors.city}</span>}
              </div>
              <div className="field">
                <label>State *</label>
                <select value={form.state} onChange={set("state")}>
                  {INDIA_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className={"field " + (errors.pincode ? "error" : "")}>
                <label>Pincode *</label>
                <input value={form.pincode} onChange={set("pincode")} placeholder="560001" maxLength={6} />
                {errors.pincode && <span className="field-error">{errors.pincode}</span>}
              </div>
            </div>
          </section>

          {/* Payment */}
          <section className="form-section">
            <h3 className="section-title">💰 Payment Method</h3>
            <div className="payment-options">
              {PAYMENT_METHODS.map(pm => (
                <label
                  key={pm.id}
                  className={"payment-option " + (paymentMethod === pm.id ? "selected" : "")}
                  onClick={() => setPaymentMethod(pm.id)}
                >
                  <input type="radio" name="payment" value={pm.id} checked={paymentMethod === pm.id} readOnly />
                  <span className="pm-icon">{pm.icon}</span>
                  <div className="pm-info">
                    <span className="pm-label">{pm.label}</span>
                    <span className="pm-desc">{pm.desc}</span>
                  </div>
                </label>
              ))}
            </div>

            {/* Payment details — shown based on selection */}
            {paymentMethod === "razorpay" && (
              <RazorpayDetails
                value={razorpayDetails}
                onChange={setRazorpayDetails}
                error={{ paymentId: errors.paymentId }}
              />
            )}
            {paymentMethod === "stripe" && (
              <StripeDetails
                value={stripeDetails}
                onChange={setStripeDetails}
                error={{ cardNumber: errors.cardNumber, expiry: errors.expiry, cvv: errors.cvv, nameOnCard: errors.nameOnCard }}
              />
            )}
            {paymentMethod === "cod" && (
              <CODDetails
                grandTotal={totals.grandTotal}
                value={codDetails}
                onChange={setCodDetails}
              />
            )}
          </section>

          {/* Notes */}
          <section className="form-section">
            <h3 className="section-title">📝 Notes (optional)</h3>
            <textarea
              className="notes-input"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Any special instructions..."
              rows={3}
            />
          </section>
        </div>

        {/* Right — Order Summary */}
        <div className="checkout-summary">
          <h3 className="summary-title">Order Summary</h3>

          <div className="checkout-items-list">
            {items.map(({ product, quantity }) => (
              <div key={product.sku} className="checkout-item">
                <span className="ci-name">{product.name}</span>
                <span className="ci-qty">×{quantity}</span>
                <span className="ci-price">{formatINR(product.price * quantity)}</span>
              </div>
            ))}
          </div>

          <div className="summary-rows">
            <div className="summary-row">
              <span>Subtotal</span>
              <span>{formatINR(totals.subtotal)}</span>
            </div>
            {totals.totalProductDiscount > 0 && (
              <div className="summary-row discount">
                <span>Product Discounts</span>
                <span>−{formatINR(totals.totalProductDiscount)}</span>
              </div>
            )}
            <div className="summary-row">
              <span>GST</span>
              <span>{formatINR(totals.totalTax)}</span>
            </div>
            {headerDiscount && (
              <div className="summary-row discount">
                <span>🎉 {headerDiscount.name} ({headerDiscount.value}%)</span>
                <span>−{formatINR(totals.headerDiscountAmount)}</span>
              </div>
            )}
            <div className="summary-divider" />
            <div className="summary-row grand-total">
              <span>Total</span>
              <span>{formatINR(totals.grandTotal)}</span>
            </div>
          </div>

          <button
            className={"place-order-btn " + (loading ? "loading" : "")}
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading
              ? <><span className="spinner" /> Processing...</>
              : "Place Order · " + formatINR(totals.grandTotal)}
          </button>

          <p className="order-note">
            Invoice will be emailed to the customer after confirmation.
          </p>
        </div>
      </div>
    </div>
  );
}