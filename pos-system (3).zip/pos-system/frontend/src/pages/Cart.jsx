import { useCart } from "../context/CartContext";
import { formatINR, getActiveHeaderDiscount, PRODUCT_DISCOUNTS } from "../data/products";

export default function Cart({ onBack, onCheckout }) {
  const { items, removeItem, updateQty, computeTotals } = useCart();
  const headerDiscount = getActiveHeaderDiscount();
  const totals = computeTotals(headerDiscount);

  if (items.length === 0) {
    return (
      <div className="page cart-page empty">
        <div className="empty-cart">
          <div className="empty-icon">🛒</div>
          <h2>Cart is empty</h2>
          <p>Add some products first</p>
          <button className="back-btn" onClick={onBack}>← Browse Products</button>
        </div>
      </div>
    );
  }

  return (
    <div className="page cart-page">
      <header className="page-header">
        <button className="back-btn" onClick={onBack}>← Products</button>
        <h2 className="page-title">🛒 Cart</h2>
        <span className="item-count">{items.length} item{items.length !== 1 ? "s" : ""}</span>
      </header>

      <div className="cart-layout">
        {/* Items */}
        <div className="cart-items">
          {items.map(({ product, quantity }) => {
            const disc     = PRODUCT_DISCOUNTS[product.sku];
            const discAmt  = disc
              ? disc.type === "percentage"
                ? (product.price * disc.value) / 100
                : disc.value
              : 0;
            const unitAfterDisc = product.price - discAmt;
            const lineTotal = unitAfterDisc * quantity;

            return (
              <div key={product.sku} className="cart-item">
                <div className="cart-item-info">
                  <h3 className="cart-item-name">{product.name}</h3>
                  <p className="cart-item-sku">{product.sku}</p>
                  <div className="cart-item-price-row">
                    {disc ? (
                      <>
                        <span className="cart-price-orig">{formatINR(product.price)}</span>
                        <span className="cart-price-disc">{formatINR(unitAfterDisc)}</span>
                        <span className="cart-disc-label">
                          {disc.type === "percentage"
                            ? `${disc.value}% off`
                            : `₹${disc.value.toLocaleString("en-IN")} off`}
                        </span>
                      </>
                    ) : (
                      <span className="cart-price-disc">{formatINR(product.price)}</span>
                    )}
                    <span className="cart-price-note">+ GST per unit</span>
                  </div>
                </div>

                <div className="cart-item-controls">
                  <div className="qty-control">
                    <button onClick={() => updateQty(product.sku, quantity - 1)}>−</button>
                    <span>{quantity}</span>
                    <button onClick={() => updateQty(product.sku, quantity + 1)}>+</button>
                  </div>
                  <div className="cart-item-line-total">{formatINR(lineTotal)}</div>
                  <button className="remove-btn" onClick={() => removeItem(product.sku)}>🗑</button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Summary */}
        <div className="cart-summary">
          <h3 className="summary-title">Order Summary</h3>

          <div className="summary-rows">
            <div className="summary-row">
              <span>Subtotal (before tax)</span>
              <span>{formatINR(totals.subtotal)}</span>
            </div>

            {totals.totalProductDiscount > 0 && (
              <div className="summary-row discount">
                <span>Product Discounts</span>
                <span>− {formatINR(totals.totalProductDiscount)}</span>
              </div>
            )}

            <div className="summary-row">
              <span>GST</span>
              <span>{formatINR(totals.totalTax)}</span>
            </div>

            {headerDiscount && (
              <div className="summary-row discount header-disc">
                <span>
                  🎉 {headerDiscount.name}
                  <small> ({headerDiscount.value}% off order)</small>
                </span>
                <span>− {formatINR(totals.headerDiscountAmount)}</span>
              </div>
            )}

            <div className="summary-divider" />

            <div className="summary-row grand-total">
              <span>Total Payable</span>
              <span>{formatINR(totals.grandTotal)}</span>
            </div>
          </div>

          {headerDiscount && (
            <div className="header-disc-banner">
              🎉 <strong>{headerDiscount.name}</strong> applied! {headerDiscount.value}% off your entire order.
            </div>
          )}

          <button className="checkout-btn" onClick={onCheckout}>
            Proceed to Checkout →
          </button>
        </div>
      </div>
    </div>
  );
}
