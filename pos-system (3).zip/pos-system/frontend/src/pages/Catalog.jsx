import { useState, useMemo } from "react";
import { PRODUCTS, COLLECTIONS, PRODUCT_DISCOUNTS, formatINR, getProductDiscountAmount } from "../data/products";
import { useCart } from "../context/CartContext";

const COLLECTION_ICONS = {
  Electronics: "⚡",
  Accessories: "🔌",
  Furniture:   "🪑",
  Clothing:    "👕",
  Medicine:    "💊",
  Toys:        "🎮",
  Sports:      "🏋️",
};

export default function Catalog({ onViewCart }) {
  const [search, setSearch]         = useState("");
  const [collection, setCollection] = useState("All");
  const [added, setAdded]           = useState({});
  const { addItem, totalItems }     = useCart();

  // Refund modal state
  const [showRefund, setShowRefund]         = useState(false);
  const [refundInvoice, setRefundInvoice]   = useState("");
  const [refundReason, setRefundReason]     = useState("");
  const [refundLoading, setRefundLoading]   = useState(false);
  const [refundResponse, setRefundResponse] = useState(null);
  const [refundError, setRefundError]       = useState("");

  const handleRefund = async () => {
    if (!refundInvoice.trim()) { setRefundError("Invoice number is required"); return; }
    if (!refundReason.trim())  { setRefundError("Reason is required"); return; }
    setRefundError("");
    setRefundLoading(true);
    try {
      const res  = await fetch("http://localhost:8000/refund", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ invoice_number: refundInvoice.trim(), reason: refundReason.trim() }),
      });
      const data = await res.json();
      setRefundResponse(data);
    } catch (err) {
      setRefundResponse({ error: true, message: err.message });
    } finally {
      setRefundLoading(false);
    }
  };

  const closeRefund = () => {
    setShowRefund(false);
    setRefundInvoice("");
    setRefundReason("");
    setRefundResponse(null);
    setRefundError("");
  };

  const filtered = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchCollection = collection === "All" || p.collection === collection;
      const matchSearch     = p.name.toLowerCase().includes(search.toLowerCase()) ||
                              p.sku.toLowerCase().includes(search.toLowerCase());
      return matchCollection && matchSearch;
    });
  }, [search, collection]);

  const handleAdd = (product) => {
    addItem(product);
    setAdded(prev => ({ ...prev, [product.sku]: true }));
    setTimeout(() => setAdded(prev => ({ ...prev, [product.sku]: false })), 1200);
  };

  return (
    <div className="page catalog-page">

      {/* Refund Modal */}
      {showRefund && (
        <div className="modal-overlay" onClick={closeRefund}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">🔄 Process Refund</h3>
              <button className="modal-close" onClick={closeRefund}>✕</button>
            </div>

            {!refundResponse ? (
              <>
                <div className="modal-body">
                  <div className="field">
                    <label>Invoice Number *</label>
                    <input
                      value={refundInvoice}
                      onChange={e => { setRefundInvoice(e.target.value); setRefundError(""); }}
                      placeholder="INV-20260408-XXXXXX"
                      autoFocus
                    />
                  </div>
                  <div className="field" style={{ marginTop: "14px" }}>
                    <label>Reason for Refund *</label>
                    <input
                      value={refundReason}
                      onChange={e => { setRefundReason(e.target.value); setRefundError(""); }}
                      placeholder="Customer changed mind"
                    />
                  </div>
                  {refundError && <p className="modal-error">{refundError}</p>}
                </div>
                <div className="modal-footer">
                  <button className="modal-cancel-btn" onClick={closeRefund}>Cancel</button>
                  <button
                    className={"modal-submit-btn" + (refundLoading ? " loading" : "")}
                    onClick={handleRefund}
                    disabled={refundLoading}
                  >
                    {refundLoading ? "Processing..." : "Submit Refund →"}
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="modal-body">
                  <div className={"refund-result-banner " + (refundResponse.error ? "error" : "success")}>
                    <span>{refundResponse.error ? "❌" : "✅"}</span>
                    <span>{refundResponse.error ? "Refund Failed" : "Refund Submitted Successfully"}</span>
                  </div>
                  <pre className="modal-response-raw">{JSON.stringify(refundResponse, null, 2)}</pre>
                </div>
                <div className="modal-footer">
                  <button className="modal-submit-btn" onClick={closeRefund}>Close</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Header */}
      <header className="catalog-header">
        <div className="brand">
          <span className="brand-icon">🏪</span>
          <div>
            <h1 className="brand-name">StoreOS</h1>
            <span className="brand-sub">Point of Sale Terminal</span>
          </div>
        </div>
        <div className="header-actions">
          <button className="refund-header-btn" onClick={() => setShowRefund(true)}>
            🔄 Refund
          </button>
          <button className="cart-btn" onClick={onViewCart}>
            <span className="cart-icon">🛒</span>
            <span className="cart-label">View Cart</span>
            {totalItems > 0 && <span className="cart-badge">{totalItems}</span>}
          </button>
        </div>
      </header>

      {/* Search + Filter */}
      <div className="controls">
        <div className="search-wrap">
          <span className="search-icon">🔍</span>
          <input
            className="search-input"
            type="text"
            placeholder="Search by name or SKU..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          {search && (
            <button className="clear-search" onClick={() => setSearch("")}>✕</button>
          )}
        </div>
        <div className="collection-tabs">
          {COLLECTIONS.map(c => (
            <button
              key={c}
              className={"col-tab" + (collection === c ? " active" : "")}
              onClick={() => setCollection(c)}
            >
              {c !== "All" && <span>{COLLECTION_ICONS[c]}</span>}
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Results count */}
      <div className="results-info">
        <span>{filtered.length} product{filtered.length !== 1 ? "s" : ""}</span>
        {search && <span className="results-query"> matching "{search}"</span>}
      </div>

      {/* Product Grid */}
      <div className="product-grid">
        {filtered.length === 0 ? (
          <div className="no-results">
            <span>😕</span>
            <p>No products found</p>
            <button onClick={() => { setSearch(""); setCollection("All"); }}>Clear filters</button>
          </div>
        ) : (
          filtered.map(product => {
            const disc       = PRODUCT_DISCOUNTS[product.sku];
            const discAmt    = getProductDiscountAmount(product.sku, product.price);
            const finalPrice = product.price - discAmt;
            const isAdded    = added[product.sku];

            return (
              <div key={product.sku} className="product-card">
                <div className="product-card-top">
                  <div className="product-collection-badge">
                    <span>{COLLECTION_ICONS[product.collection]}</span>
                    {product.collection}
                  </div>
                  {disc && (
                    <div className={"discount-badge " + disc.type}>
                      {disc.type === "percentage"
                        ? disc.value + "% OFF"
                        : "₹" + disc.value.toLocaleString("en-IN") + " OFF"}
                    </div>
                  )}
                </div>

                <h3 className="product-name">{product.name}</h3>
                <p className="product-sku">SKU: {product.sku}</p>

                <div className="product-pricing">
                  {disc ? (
                    <>
                      <span className="price-original">{formatINR(product.price)}</span>
                      <span className="price-final">{formatINR(finalPrice)}</span>
                      <span className="price-note">+ GST</span>
                    </>
                  ) : (
                    <>
                      <span className="price-final">{formatINR(product.price)}</span>
                      <span className="price-note">+ GST</span>
                    </>
                  )}
                </div>

                <button
                  className={"add-btn" + (isAdded ? " added" : "")}
                  onClick={() => handleAdd(product)}
                >
                  {isAdded ? "✓ Added!" : "+ Add to Cart"}
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}