import { useState } from "react";

export default function ResponseScreen({ response, orderPayload, onNewOrder }) {
  const [refundInvoice, setRefundInvoice] = useState("");
  const [refundReason,  setRefundReason]  = useState("");
  const [refundLoading, setRefundLoading] = useState(false);
  const [refundResponse, setRefundResponse] = useState(null);
  const [showRaw, setShowRaw] = useState(false);

  const isError = response?.error === true;

  // Try to extract invoice number from n8n response
  const invoiceNumber =
    response?.invoice_number ||
    response?.data?.invoice_number ||
    response?.invoice?.invoice_number ||
    null;

  const handleRefund = async () => {
    if (!refundInvoice.trim() || !refundReason.trim()) return;
    setRefundLoading(true);
    try {
      const res = await fetch("http://localhost:8000/refund", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({
          invoice_number: refundInvoice.trim(),
          reason:         refundReason.trim(),
        }),
      });
      const data = await res.json();
      setRefundResponse(data);
    } catch (err) {
      setRefundResponse({ error: true, message: err.message });
    } finally {
      setRefundLoading(false);
    }
  };

  return (
    <div className="page response-page">
      <div className="response-container">
        {/* Status Banner */}
        <div className={`status-banner ${isError ? "error" : "success"}`}>
          <span className="status-icon">{isError ? "❌" : "✅"}</span>
          <div>
            <h2 className="status-title">
              {isError ? "Order Failed" : "Order Placed Successfully"}
            </h2>
            {invoiceNumber && (
              <p className="status-invoice">Invoice: <strong>{invoiceNumber}</strong></p>
            )}
            {!isError && (
              <p className="status-sub">Invoice will be sent to customer's email.</p>
            )}
          </div>
        </div>

        {/* Order summary pill */}
        {orderPayload && (
          <div className="order-pill">
            <span>👤 {orderPayload.customer.name}</span>
            <span>·</span>
            <span>📧 {orderPayload.customer.email}</span>
            <span>·</span>
            <span>💳 {orderPayload.payment_method.toUpperCase()}</span>
            <span>·</span>
            <span>📦 {orderPayload.items.length} item{orderPayload.items.length !== 1 ? "s" : ""}</span>
          </div>
        )}

        {/* n8n Response */}
        <div className="response-section">
          <div className="response-section-header">
            <h3>n8n Webhook Response</h3>
            <button
              className="toggle-raw"
              onClick={() => setShowRaw(v => !v)}
            >
              {showRaw ? "Hide Raw" : "Show Raw JSON"}
            </button>
          </div>

          {showRaw ? (
            <pre className="response-raw">{JSON.stringify(response, null, 2)}</pre>
          ) : (
            <div className="response-pretty">
              {renderPretty(response)}
            </div>
          )}
        </div>

        {/* Refund Panel */}
        <div className="refund-section">
          <h3 className="refund-title">🔄 Process a Refund</h3>
          <div className="refund-form">
            <div className="field">
              <label>Invoice Number</label>
              <input
                value={refundInvoice}
                onChange={e => setRefundInvoice(e.target.value)}
                placeholder={invoiceNumber || "INV-20260408-XXXXXX"}
              />
            </div>
            <div className="field">
              <label>Reason for Refund</label>
              <input
                value={refundReason}
                onChange={e => setRefundReason(e.target.value)}
                placeholder="Customer changed mind"
              />
            </div>
            <button
              className={`refund-btn ${refundLoading ? "loading" : ""}`}
              onClick={handleRefund}
              disabled={refundLoading || !refundInvoice.trim() || !refundReason.trim()}
            >
              {refundLoading ? "⏳ Processing..." : "Submit Refund →"}
            </button>
          </div>

          {refundResponse && (
            <div className="refund-response">
              <h4>Refund Response</h4>
              <pre className="response-raw">{JSON.stringify(refundResponse, null, 2)}</pre>
            </div>
          )}
        </div>

        {/* New Order */}
        <div className="new-order-wrap">
          <button className="new-order-btn" onClick={onNewOrder}>
            🛒 Start New Order
          </button>
        </div>
      </div>
    </div>
  );
}

// Render n8n response as readable key-value pairs
function renderPretty(data) {
  if (!data || typeof data !== "object") {
    return <p className="response-plain">{String(data)}</p>;
  }
  return (
    <div className="response-kv">
      {Object.entries(data).map(([key, val]) => (
        <div key={key} className="kv-row">
          <span className="kv-key">{key}</span>
          <span className="kv-val">
            {typeof val === "object"
              ? <pre>{JSON.stringify(val, null, 2)}</pre>
              : String(val)}
          </span>
        </div>
      ))}
    </div>
  );
}
