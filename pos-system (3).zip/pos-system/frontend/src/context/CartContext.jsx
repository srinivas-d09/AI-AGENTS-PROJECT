import { createContext, useContext, useState } from "react";
import { getProductDiscountAmount, HSN_TAX } from "../data/products";

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState([]); // { product, quantity }

  const addItem = (product) => {
    setItems(prev => {
      const existing = prev.find(i => i.product.sku === product.sku);
      if (existing) {
        return prev.map(i =>
          i.product.sku === product.sku
            ? { ...i, quantity: i.quantity + 1 }
            : i
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeItem = (sku) => {
    setItems(prev => prev.filter(i => i.product.sku !== sku));
  };

  const updateQty = (sku, qty) => {
    if (qty <= 0) { removeItem(sku); return; }
    setItems(prev => prev.map(i =>
      i.product.sku === sku ? { ...i, quantity: qty } : i
    ));
  };

  const clearCart = () => setItems([]);

  // Compute totals
  const computeTotals = (headerDiscount = null) => {
    let subtotal = 0;
    let totalProductDiscount = 0;
    let totalTax = 0;

    const lineItems = items.map(({ product, quantity }) => {
      const basePrice      = product.price;
      const discountAmt    = getProductDiscountAmount(product.sku, basePrice);
      const discountedPrice = basePrice - discountAmt;
      const taxRate        = HSN_TAX[product.hsn_code] || 0;
      const taxAmt         = parseFloat(((discountedPrice * taxRate) / 100).toFixed(2));
      const lineTotal      = parseFloat(((discountedPrice + taxAmt) * quantity).toFixed(2));

      subtotal           += discountedPrice * quantity;
      totalProductDiscount += discountAmt * quantity;
      totalTax           += taxAmt * quantity;

      return {
        sku:        product.sku,
        name:       product.name,
        quantity,
        unit_price:      basePrice,
        discount_amount: discountAmt * quantity,
        taxable_amount:  parseFloat((discountedPrice * quantity).toFixed(2)),
        tax_rate:   taxRate,
        tax_amount: parseFloat((taxAmt * quantity).toFixed(2)),
        line_total: lineTotal,
      };
    });

    const afterTaxTotal = subtotal + totalTax;
    let headerDiscountAmount = 0;
    if (headerDiscount) {
      headerDiscountAmount = parseFloat(((afterTaxTotal * headerDiscount.value) / 100).toFixed(2));
    }
    const grandTotal = parseFloat((afterTaxTotal - headerDiscountAmount).toFixed(2));

    return {
      lineItems,
      subtotal:             parseFloat(subtotal.toFixed(2)),
      totalProductDiscount: parseFloat(totalProductDiscount.toFixed(2)),
      totalTax:             parseFloat(totalTax.toFixed(2)),
      headerDiscountAmount,
      grandTotal,
    };
  };

  const totalItems = items.reduce((s, i) => s + i.quantity, 0);

  return (
    <CartContext.Provider value={{
      items, addItem, removeItem, updateQty, clearCart, computeTotals, totalItems
    }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
