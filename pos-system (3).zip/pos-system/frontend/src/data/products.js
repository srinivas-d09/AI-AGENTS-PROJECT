// Hardcoded from DB seed data
// products + price + hsn_tax + active discounts

export const HSN_TAX = {
  "8471": 18.00, // Laptops
  "8517": 18.00, // Mobiles
  "8544": 18.00, // Cables
  "9403": 18.00, // Furniture
  "6101":  5.00, // Clothing
  "3004":  5.00, // Medicine
  "9503": 12.00, // Toys
  "9506": 18.00, // Sports
};

export const PRODUCTS = [
  // Electronics — Laptops
  { sku: "LAPTOP-001", name: "Dell Inspiron 15 Laptop",     collection: "Electronics", hsn_code: "8471", price: 55000.00 },
  { sku: "LAPTOP-002", name: "Apple MacBook Air M2",         collection: "Electronics", hsn_code: "8471", price: 114900.00 },
  { sku: "LAPTOP-003", name: "HP Pavilion x360",             collection: "Electronics", hsn_code: "8471", price: 42000.00 },
  // Electronics — Mobiles
  { sku: "MOBILE-001", name: "Samsung Galaxy S24",           collection: "Electronics", hsn_code: "8517", price: 74999.00 },
  { sku: "MOBILE-002", name: "iPhone 15",                    collection: "Electronics", hsn_code: "8517", price: 79900.00 },
  { sku: "MOBILE-003", name: "OnePlus 12",                   collection: "Electronics", hsn_code: "8517", price: 64999.00 },
  { sku: "MOBILE-004", name: "Redmi Note 13 Pro",            collection: "Electronics", hsn_code: "8517", price: 24999.00 },
  // Accessories
  { sku: "CABLE-USB-C", name: "Anker USB-C to USB-C Cable 2m", collection: "Accessories", hsn_code: "8544", price: 999.00 },
  { sku: "CABLE-HDMI",  name: "AmazonBasics HDMI Cable 3m",    collection: "Accessories", hsn_code: "8544", price: 599.00 },
  // Furniture
  { sku: "CHAIR-001", name: "ErgoSeat Pro Office Chair",     collection: "Furniture",    hsn_code: "9403", price: 12500.00 },
  { sku: "DESK-001",  name: "Wooden Study Desk 4ft",         collection: "Furniture",    hsn_code: "9403", price: 18000.00 },
  // Clothing
  { sku: "SHIRT-001",  name: "Cotton Formal Shirt — White L", collection: "Clothing",   hsn_code: "6101", price: 1299.00 },
  { sku: "SHIRT-002",  name: "Cotton Formal Shirt — Blue M",  collection: "Clothing",   hsn_code: "6101", price: 1299.00 },
  { sku: "TSHIRT-001", name: "Round Neck T-Shirt — Black XL", collection: "Clothing",   hsn_code: "6101", price: 499.00 },
  // Medicine
  { sku: "MED-PARA-500", name: "Paracetamol 500mg Strip of 10",  collection: "Medicine", hsn_code: "3004", price: 25.00 },
  { sku: "MED-VITA-C",   name: "Vitamin C 1000mg — 60 Tablets",  collection: "Medicine", hsn_code: "3004", price: 349.00 },
  // Toys
  { sku: "TOY-LEGO-001", name: "LEGO Classic Brick Box 300pcs", collection: "Toys",   hsn_code: "9503", price: 3499.00 },
  { sku: "TOY-CAR-001",  name: "Remote Control Racing Car",      collection: "Toys",   hsn_code: "9503", price: 1799.00 },
  // Sports
  { sku: "SPORT-YOGA", name: "Premium Yoga Mat 6mm",   collection: "Sports", hsn_code: "9506", price: 899.00 },
  { sku: "SPORT-DUMB", name: "Dumbbell Set 5kg pair",  collection: "Sports", hsn_code: "9506", price: 1499.00 },
];

// Active product discounts from seed data
export const PRODUCT_DISCOUNTS = {
  "LAPTOP-001":  { type: "percentage", value: 10.00,   name: "Laptop Special Offer" },
  "LAPTOP-002":  { type: "fixed",      value: 5000.00, name: "MacBook Discount" },
  "MOBILE-001":  { type: "percentage", value: 5.00,    name: "Samsung Deal" },
  "MOBILE-002":  { type: "fixed",      value: 2000.00, name: "iPhone Offer" },
  "CABLE-USB-C": { type: "fixed",      value: 100.00,  name: "Cable Offer" },
};

// Header discounts — only date-range-active ones shown
// (Diwali: Oct 20–25 2026, New Year: Dec 31–Jan 2, Independence Day: Aug 14–15 2026)
// None are active right now (Apr 2026) — so header discount = null at runtime
export const HEADER_DISCOUNTS = [
  { name: "Diwali Sale",           value: 15.00, start: "2026-10-20", end: "2026-10-25" },
  { name: "New Year Sale",         value: 10.00, start: "2026-12-31", end: "2027-01-02" },
  { name: "Independence Day Sale", value: 8.00,  start: "2026-08-14", end: "2026-08-15" },
];

export const COLLECTIONS = ["All", ...new Set(PRODUCTS.map(p => p.collection))];

// Returns the active header discount (highest %) or null
export function getActiveHeaderDiscount() {
  const now = new Date();
  const active = HEADER_DISCOUNTS.filter(d => {
    const start = new Date(d.start);
    const end   = new Date(d.end + "T23:59:59");
    return now >= start && now <= end;
  });
  if (!active.length) return null;
  return active.sort((a, b) => b.value - a.value)[0];
}

// Calculate product discount amount for a product
export function getProductDiscountAmount(sku, basePrice) {
  const disc = PRODUCT_DISCOUNTS[sku];
  if (!disc) return 0;
  if (disc.type === "percentage") return parseFloat(((basePrice * disc.value) / 100).toFixed(2));
  return disc.value;
}

export function formatINR(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
  }).format(amount);
}
