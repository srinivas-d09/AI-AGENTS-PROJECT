from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import httpx
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="POS Proxy API", version="1.0.0")

# CORS — allow React on port 3000
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

N8N_ORDER_WEBHOOK  = os.getenv("N8N_ORDER_WEBHOOK", )
N8N_REFUND_WEBHOOK = os.getenv("N8N_REFUND_WEBHOOK", )

TIMEOUT = 60.0  # seconds — n8n can be slow


@app.get("/health")
async def health():
    return {"status": "ok", "service": "POS Proxy API"}


@app.post("/order")
async def create_order(request: Request):
    """
    Receive order payload from React, forward to n8n, return n8n response.

    Expected payload:
    {
      "customer": {
        "name": "...",
        "email": "...",
        "phone": "...",
        "address": { "line1": "...", "city": "...", "state": "...", "pincode": "..." }
      },
      "items": [ { "sku": "...", "quantity": 1 } ],
      "payment_method": "razorpay" | "stripe" | "cod",
      "notes": "..."
    }
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    # Basic validation
    if "customer" not in body or "items" not in body:
        raise HTTPException(status_code=422, detail="Missing required fields: customer, items")

    customer = body.get("customer", {})
    if not customer.get("name") or not customer.get("email"):
        raise HTTPException(status_code=422, detail="Customer name and email are required")

    items = body.get("items", [])
    if not items or len(items) == 0:
        raise HTTPException(status_code=422, detail="Order must have at least one item")

    payment_method = body.get("payment_method", "cod")
    if payment_method not in ("razorpay", "stripe", "cod"):
        raise HTTPException(status_code=422, detail="payment_method must be razorpay, stripe, or cod")

    # Forward to n8n
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            response = await client.post(N8N_ORDER_WEBHOOK, json=body)
            try:
                n8n_data = response.json()
            except Exception:
                n8n_data = {"raw": response.text}

            return JSONResponse(
                content=n8n_data,
                status_code=response.status_code if response.status_code < 500 else 200
            )

    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Cannot connect to n8n. Make sure n8n is running on port 5678."
        )
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail="n8n webhook timed out. Check your n8n workflow."
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Proxy error: {str(e)}")


@app.post("/refund")
async def refund_order(request: Request):
    """
    Receive refund payload from React, forward to n8n, return n8n response.

    Expected payload:
    {
      "invoice_number": "INV-20260408-254632",
      "reason": "Customer changed mind"
    }
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    if not body.get("invoice_number"):
        raise HTTPException(status_code=422, detail="invoice_number is required")

    if not body.get("reason"):
        raise HTTPException(status_code=422, detail="reason is required")

    # Forward to n8n
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            response = await client.post(N8N_REFUND_WEBHOOK, json=body)
            try:
                n8n_data = response.json()
            except Exception:
                n8n_data = {"raw": response.text}

            return JSONResponse(
                content=n8n_data,
                status_code=response.status_code if response.status_code < 500 else 200
            )

    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Cannot connect to n8n. Make sure n8n is running on port 5678."
        )
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail="n8n webhook timed out. Check your n8n workflow."
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Proxy error: {str(e)}")
